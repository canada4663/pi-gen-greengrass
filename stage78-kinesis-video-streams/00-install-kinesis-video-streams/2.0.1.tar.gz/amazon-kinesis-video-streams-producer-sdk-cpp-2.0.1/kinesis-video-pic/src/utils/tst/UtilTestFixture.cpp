#include "UtilTestFixture.h"

UINT64 gTotalUtilsMemoryUsage = 0;
MUTEX gUtilityMemMutex;