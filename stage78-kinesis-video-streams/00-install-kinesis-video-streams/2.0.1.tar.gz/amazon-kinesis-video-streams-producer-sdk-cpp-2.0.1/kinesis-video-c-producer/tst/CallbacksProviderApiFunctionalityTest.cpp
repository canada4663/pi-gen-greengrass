#include "ProducerTestFixture.h"

namespace com { namespace amazonaws { namespace kinesis { namespace video {

class CallbacksProviderApiFunctionalityTest : public ProducerClientTestBase {
};

TEST_F(CallbacksProviderApiFunctionalityTest, foo_bar_baz_test)
{
}

}  // namespace video
}  // namespace kinesis
}  // namespace amazonaws
}  // namespace com;
